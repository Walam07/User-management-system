<?php
// session_start();


//$con = new mysqli("localhost", "root", "", "finalproject") or die("connection failed");
//echo "Connection successfull";

$con = mysqli_connect("localhost", "root", "", "finalproject") or die("connection failed");



?>





